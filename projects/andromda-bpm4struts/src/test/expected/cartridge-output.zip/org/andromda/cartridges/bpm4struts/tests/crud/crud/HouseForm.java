/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.crud.crud;

public final class HouseForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{
    private java.util.List manageableList = null;

    public java.util.List getManageableList()
    {
        return this.manageableList;
    }

    public void setManageableList(java.util.List manageableList)
    {
        this.manageableList = manageableList;
    }

    private java.lang.Long[] selectedRows = null;

    public java.lang.Long[] getSelectedRows()
    {
        return this.selectedRows;
    }

    public void setSelectedRows(java.lang.Long[] selectedRows)
    {
        this.selectedRows = selectedRows;
    }

    private java.lang.String something;

    public java.lang.String getSomething()
    {
        return this.something;
    }

    public void setSomething(java.lang.String something)
    {
        this.something = something;
    }

    private java.lang.String enumAttribute;

    public java.lang.String getEnumAttribute()
    {
        return this.enumAttribute;
    }

    public void setEnumAttribute(java.lang.String enumAttribute)
    {
        this.enumAttribute = enumAttribute;
    }

    private java.lang.Long id;

    public java.lang.Long getId()
    {
        return this.id;
    }

    public void setId(java.lang.Long id)
    {
        this.id = id;
    }

    private java.lang.Long[] gardens;

    public java.lang.Long[] getGardens()
    {
        return this.gardens;
    }

    public void setGardens(java.lang.Long[] gardens)
    {
        this.gardens = gardens;
    }

    private java.util.List gardensBackingList;

    public java.util.List getGardensBackingList()
    {
        return this.gardensBackingList;
    }

    public void setGardensBackingList(java.util.List gardensBackingList)
    {
        this.gardensBackingList = gardensBackingList;
    }

    private java.lang.Long room;

    public java.lang.Long getRoom()
    {
        return this.room;
    }

    public void setRoom(java.lang.Long room)
    {
        this.room = room;
    }

    private java.util.List roomBackingList;

    public java.util.List getRoomBackingList()
    {
        return this.roomBackingList;
    }

    public void setRoomBackingList(java.util.List roomBackingList)
    {
        this.roomBackingList = roomBackingList;
    }

    /**
     * @see org.apache.struts.validator.ValidatorForm#reset(org.apache.struts.action.ActionMapping,javax.servlet.http.HttpServletRequest)
     */
    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
        something = null;
        enumAttribute = null;
        id = null;
        gardens = null;
        gardensBackingList = null;
        room = null;
        roomBackingList = null;
    }
}