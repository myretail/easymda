/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.services;

/**
 * This form encapsulates the fields that are used in the execution of the
 * <code>crapmeout</code> method, which is located on the
 * <code>org.andromda.cartridges.bpm4struts.tests.services.Controller</code> controller.
 *
 * 
 *
 * @see org.andromda.cartridges.bpm4struts.tests.services.Controller#crapmeout
 */
public interface CrapmeoutForm
{
}
